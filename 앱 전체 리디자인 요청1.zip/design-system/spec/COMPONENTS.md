# 컴포넌트 명세 / Component Spec — 혜니캘린더

> 값은 토큰명으로 표기(`color.*`, `radius.*`, `space.*`, `shadow.*`, `type.*` = `tokens/theme.ts`).
> 먼저 이 8종 기본 컴포넌트를 만들고, 화면은 그 위에 조립하세요.

공통 규칙 / Global rules
- **탭 피드백:** 눌림 시 `transform: scale(0.96)` (`motion.pressScale`), `duration.fast` `easing.standard`.
- **최소 터치 44×44.** 아이콘 버튼도 히트영역 44 확보.
- **카드 언어 통일:** `bg.card` + `radius.card(24)` + `border 1px line.hair` + `shadow.card`. 예외 없이.
- 색은 역할대로(로즈=기본/부모·아이, 민트=안전/선생님, 라벤더=AI, 골드=보상, danger=위험).

---

## 1. Button
| 변형 / Variant | 배경 | 텍스트 | 높이 | radius | 그림자 |
|---|---|---|---|---|---|
| Primary (rose) | gradient `rose.light→rose.deep` | #fff, `type.bodyLg` | 56 | xl(18) | `shadow.roseButton` |
| Primary (mint) | gradient `mint.light→mint.deep` | #fff | 50–56 | lg–xl | `shadow.mint` |
| Primary (AI) | gradient `lavender.light→lavender.mid` | #fff | 56 | xl | `shadow.lavender` |
| Secondary | `bg.card` + border `line.strong` | `fg.secondary` | 48–52 | lg | none |
| Tint chip-button | `rose.soft` | `rose.text` | 34–40 | pill | none |
| Icon-circle | `bg.card` | icon `fg.secondary` | 42 | pill | `shadow.soft` |

상태 / States: default · press(scale .96) · disabled(`bg` muted, `fg.disabled`) · loading(스피너, 라벨 유지). 아이콘+라벨은 `gap 8`.

## 2. 하트 "꾹" 버튼 / Heart "kkuk" button
- 부모 헤더의 시그니처 액션. 실제 하트 SVG(`rose.light→rose.deep` gradient) 46px + 중앙 "꾹" 텍스트(`#fff`, 11px/900).
- 탭 → 아이에게 하트 전송(토스트 "지우에게 하트를 꾹 보냈어요 💗"). press `scale .84`.

## 3. Card
- **Base:** 공통 카드 언어(위 규칙). padding `space.4`.
- **Hero (gradient):** `radius.hero(26)` + 역할 gradient + 해당 컬러 shadow + 우하단 마스코트(`hy-float` 애니메이션). 텍스트 흰색, `type.titleXl`.
- **Stat/metric:** 2×2 그리드, 각 셀 = 틴트 아이콘 타일(42, radius.md) + 라벨(caption `fg.faint`) + 값(`type.section`/tabular-nums).

## 4. SectionHeader
- 구성: 틴트 아이콘 타일(30, radius.sm) + 제목(`type.section` `fg.primary`) + (선택) 우측 메타 칩 또는 "전체보기 ›" 링크(`rose.text` `type.label`).
- 섹션마다 이 한 패턴만. 아이콘 타일 배경 = 섹션 성격색의 soft.

## 5. ListRow (일정/현황 행)
- 좌: 카테고리 3D 아이콘 타일(48, radius.lg, 카테고리 soft색). 중: 제목(`type.body`) + 서브(caption `fg.faint`). 우: 상태 태그(§7) 또는 chevron.
- press 시 배경 `bg.press`. 행 높이 ≥ 60.

## 6. Avatar
- 크기: 26(칩) · 44(행) · 46(팩) · 60(현황). radius = 크기의 ~0.3 (rounded square), 배경 = 아이 soft색, 3D 동물/가족 이미지.
- **라이브 점:** 우하단 `mint.base` 원 + 2.5px 흰 테두리(실시간 위치 표시).

## 7. Chip / Tag
| 종류 | 배경 | 텍스트 |
|---|---|---|
| 안전/참석 | `mint.soft` | `mint.text` |
| 임박/기본 | `rose.soft` | `rose.text` |
| AI/숙제 | `lavender.soft` | `lavender.text` |
| 보상 | `cream.soft` | `gold.text` |
| 위험 | `danger.soft` | `danger.text` |
- 높이 24–28, `radius.pill`, `type.micro`~`tiny`. 상태색은 **색+텍스트** 동반(색맹 대응). 실시간 뱃지는 앞에 맥동 점(`hy-soft`).

## 8. Checklist item (준비물·숙제) — 편집 가능 / editable
- 행: 체크박스(26, radius.sm — 완료 시 `mint` gradient+흰 체크) + 라벨. 숙제는 `lavender` "숙제" 태그.
- **편집 모드:** 헤더 "편집" 토글 → 라벨이 인풋(`bg.press`)으로, 우측 삭제(×, `danger.soft`), 하단 "+ 준비물 / + 숙제" 추가 버튼(점선 보더). 개수 `n/총계`는 실시간.
- RN: 항목 배열 상태 + FlatList. IME 안정 위해 비제어 입력(onEndEditing로 커밋) 권장.

## 9. SegmentedControl
- 용도: AI 입력 방식(음성·텍스트·알림장), 느낌 트윅. 트랙 `lavender.soft`(8% 틴트), 선택 칩 `bg.card` + `shadow.soft` + `lavender.text`, 비선택 `fg.muted`.
- 2–3개 짧은 라벨. 그 이상은 드롭다운.

## 10. Switch / Toggle
- 48×28 트랙, 24 노브(흰, `shadow.soft`). on=`mint.base`, off=`#E3DCE0`. 전환 `duration.base`. 자동충전·알림 설정 등.

## 11. TabBar
- 플로팅 흰 바(`radius.hero`, `shadow.floating`), 상단 그라데이션 페이드. 아이템 = 아이콘(23) + 라벨(`type.tiny`). 활성 = 아이콘 틴트 타일 + 강조색, 비활성 `fg.disabled`. 배지 점(danger).

## 12. BottomSheet / Modal / Toast
- **Sheet:** 상단 그래버(40×5, `line.strong`), `radius.3xl` 상단만, `shadow.floating`, 백드롭 `scrim`. 등장 `hy-sheetup` `easing.standard`.
- **Modal(통화 등):** 중앙 카드, 백드롭 딤.
- **Toast:** 하단 중앙 알약, 아이콘+문구, `hy-toast` 등장 후 자동 소멸(~2s). 예: "일정을 추가했어요 ✅".

## 13. Input / Textarea
- 배경 `bg.press` 또는 `bg.card`+border `line.soft`, `radius.md`, 높이 48(인풋)·120+(텍스트영역), `type.bodySm`. placeholder `fg.faint`. 포커스 시 border 강조. RN: 한글 IME 안정 위해 비제어 지향.

## 14. Splash (오프라인 빌드용)
- 풀스크린 `rose.brand` 배경 + 흰 폰+하트 SVG. 로드 후 페이드아웃(.45s) 뒤 제거. (스탠드얼론 HTML 한정)

---

## 카테고리 아이콘 세트 / Category icons
학교·태권도·미술·음악·수영·축구·공부·취미·친구·가족 등 전용 3D webp. 각 카테고리에 soft 배경색 매핑(`_catMap` 참고). RN에선 @1x~@3x 래스터 또는 동등 SVG로 대체.

## 애니메이션 / Animations (keyframes)
`hy-float`(마스코트 부유) · `hy-bob`(상하) · `hy-ring`(맥동 링) · `hy-rise/fadein`(화면 등장) · `hy-sparkle`(반짝) · `hy-wave`(음성 바) · `hy-sheetup`(시트). 전부 `prefers-reduced-motion`/`data-motion="calm"`에서 정지.
